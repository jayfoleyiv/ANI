These two folders contain data files for 2-atom and 5-atom boron structures.

Folder names refer to strain applied along x and y axes, respectively. 
For example, m63=(-6,3), where 6% compressive strain is applied along x-axis and 3% tensile strain is along y-axis.

In these simulations I had 12 Angstroms of vacuum.
